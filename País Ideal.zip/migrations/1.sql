
CREATE TABLE quiz_responses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT,
  email TEXT NOT NULL,
  age INTEGER,
  current_location TEXT,
  climate_preference TEXT,
  language_preference TEXT,
  city_size_preference TEXT,
  lifestyle_preference TEXT,
  environment_preference TEXT,
  security_importance TEXT,
  cultural_adaptability TEXT,
  cost_vs_quality_preference TEXT,
  professional_area TEXT,
  culinary_preference TEXT,
  winter_tolerance TEXT,
  relocation_purpose TEXT,
  social_policies_importance TEXT,
  nature_vs_urban TEXT,
  proximity_to_brazilians TEXT,
  social_discipline_preference TEXT,
  individual_freedom_importance TEXT,
  monthly_budget TEXT,
  main_motivation TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE country_recommendations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quiz_response_id INTEGER NOT NULL,
  country_name TEXT NOT NULL,
  match_score INTEGER NOT NULL,
  ranking INTEGER NOT NULL,
  reasons TEXT,
  visa_info TEXT,
  language_info TEXT,
  cost_of_living TEXT,
  opportunities TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE payment_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quiz_response_id INTEGER NOT NULL,
  payment_method TEXT NOT NULL,
  payment_status TEXT DEFAULT 'pending',
  amount_cents INTEGER NOT NULL,
  currency TEXT DEFAULT 'BRL',
  transaction_id TEXT,
  report_sent BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_quiz_responses_user_id ON quiz_responses(user_id);
CREATE INDEX idx_quiz_responses_email ON quiz_responses(email);
CREATE INDEX idx_country_recommendations_quiz_response_id ON country_recommendations(quiz_response_id);
CREATE INDEX idx_payment_records_quiz_response_id ON payment_records(quiz_response_id);
