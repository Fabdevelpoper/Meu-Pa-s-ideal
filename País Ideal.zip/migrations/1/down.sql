
DROP INDEX idx_payment_records_quiz_response_id;
DROP INDEX idx_country_recommendations_quiz_response_id;
DROP INDEX idx_quiz_responses_email;
DROP INDEX idx_quiz_responses_user_id;
DROP TABLE payment_records;
DROP TABLE country_recommendations;
DROP TABLE quiz_responses;
