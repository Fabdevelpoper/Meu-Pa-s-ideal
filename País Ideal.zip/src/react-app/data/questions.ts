import type { Question } from "@/shared/types";

export const questions: Question[] = [
  {
    id: 'age',
    text: 'Qual é a sua idade?',
    type: 'number',
    required: true
  },
  {
    id: 'current_location',
    text: 'De onde você é (país ou cidade atual)?',
    type: 'input',
    required: true
  },
  {
    id: 'climate_preference',
    text: 'Você prefere clima quente, frio ou temperado?',
    type: 'select',
    options: [
      { value: 'quente', label: 'Quente' },
      { value: 'frio', label: 'Frio' },
      { value: 'temperado', label: 'Temperado' }
    ],
    required: true
  },
  {
    id: 'language_preference',
    text: 'Qual idioma você fala (ou está disposto(a) a aprender)?',
    type: 'input',
    required: true
  },
  {
    id: 'city_size_preference',
    text: 'Prefere cidades grandes, médias ou pequenas?',
    type: 'select',
    options: [
      { value: 'grandes', label: 'Grandes' },
      { value: 'medias', label: 'Médias' },
      { value: 'pequenas', label: 'Pequenas' }
    ],
    required: true
  },
  {
    id: 'lifestyle_preference',
    text: 'Qual estilo de vida você busca?',
    type: 'select',
    options: [
      { value: 'tranquilo', label: 'Tranquilo' },
      { value: 'agitado', label: 'Agitado' },
      { value: 'equilibrado', label: 'Equilibrado' }
    ],
    required: true
  },
  {
    id: 'environment_preference',
    text: 'Gosta de viver perto do mar, montanhas ou campos?',
    type: 'select',
    options: [
      { value: 'mar', label: 'Mar' },
      { value: 'montanhas', label: 'Montanhas' },
      { value: 'campos', label: 'Campos' }
    ],
    required: true
  },
  {
    id: 'security_importance',
    text: 'Quanto você valoriza a segurança pública?',
    type: 'select',
    options: [
      { value: 'pouco', label: 'Pouco' },
      { value: 'medio', label: 'Médio' },
      { value: 'muito', label: 'Muito' }
    ],
    required: true
  },
  {
    id: 'cultural_adaptability',
    text: 'Você se adapta facilmente a novas culturas?',
    type: 'select',
    options: [
      { value: 'sim', label: 'Sim' },
      { value: 'nao', label: 'Não' },
      { value: 'depende', label: 'Depende' }
    ],
    required: true
  },
  {
    id: 'cost_vs_quality_preference',
    text: 'Prefere países com custo de vida baixo ou alta qualidade de vida, mesmo que mais caros?',
    type: 'select',
    options: [
      { value: 'custo_baixo', label: 'Custo de vida baixo' },
      { value: 'alta_qualidade', label: 'Alta qualidade de vida' }
    ],
    required: true
  },
  {
    id: 'professional_area',
    text: 'Qual é a sua área profissional ou principal fonte de renda?',
    type: 'input',
    required: true
  },
  {
    id: 'culinary_preference',
    text: 'Gosta de culinária diversificada ou prefere sabores tradicionais?',
    type: 'select',
    options: [
      { value: 'diversificada', label: 'Culinária diversificada' },
      { value: 'tradicional', label: 'Sabores tradicionais' }
    ],
    required: true
  },
  {
    id: 'winter_tolerance',
    text: 'Você está disposto(a) a enfrentar invernos rigorosos?',
    type: 'select',
    options: [
      { value: 'sim', label: 'Sim' },
      { value: 'nao', label: 'Não' }
    ],
    required: true
  },
  {
    id: 'relocation_purpose',
    text: 'Sua mudança busca estudo, trabalho ou aposentadoria?',
    type: 'select',
    options: [
      { value: 'estudo', label: 'Estudo' },
      { value: 'trabalho', label: 'Trabalho' },
      { value: 'aposentadoria', label: 'Aposentadoria' }
    ],
    required: true
  },
  {
    id: 'social_policies_importance',
    text: 'Você valoriza políticas sociais e igualdade?',
    type: 'select',
    options: [
      { value: 'sim', label: 'Sim' },
      { value: 'nao', label: 'Não' }
    ],
    required: true
  },
  {
    id: 'nature_vs_urban',
    text: 'Prefere viver em lugares com muita natureza ou centros urbanos?',
    type: 'select',
    options: [
      { value: 'natureza', label: 'Muita natureza' },
      { value: 'urbano', label: 'Centros urbanos' }
    ],
    required: true
  },
  {
    id: 'proximity_to_brazilians',
    text: 'É importante estar perto de outros brasileiros?',
    type: 'select',
    options: [
      { value: 'sim', label: 'Sim' },
      { value: 'nao', label: 'Não' }
    ],
    required: true
  },
  {
    id: 'social_discipline_preference',
    text: 'Você gosta de regras e disciplina social?',
    type: 'select',
    options: [
      { value: 'sim', label: 'Sim' },
      { value: 'nao', label: 'Não' }
    ],
    required: true
  },
  {
    id: 'individual_freedom_importance',
    text: 'Quanto você valoriza a liberdade individual?',
    type: 'select',
    options: [
      { value: 'pouco', label: 'Pouco' },
      { value: 'medio', label: 'Médio' },
      { value: 'muito', label: 'Muito' }
    ],
    required: true
  },
  {
    id: 'monthly_budget',
    text: 'Qual é o seu orçamento mensal disponível para viver no exterior (em reais, dólares ou euros)?',
    type: 'input',
    required: true
  },
  {
    id: 'main_motivation',
    text: 'Qual é a sua principal motivação para mudar de país?',
    type: 'input',
    required: true
  },
  {
    id: 'email',
    text: 'Seu email para receber o relatório personalizado:',
    type: 'input',
    required: true
  }
];
