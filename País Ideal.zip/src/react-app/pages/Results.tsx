import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { ArrowRight, MapPin, DollarSign, FileText, Globe, CreditCard } from 'lucide-react';
import type { CountryRecommendation } from '@/shared/types';

export default function ResultsPage() {
  const { quizId } = useParams();
  const navigate = useNavigate();
  const [recommendations, setRecommendations] = useState<CountryRecommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (quizId) {
      fetchResults();
    }
  }, [quizId]);

  const fetchResults = async () => {
    try {
      const response = await fetch(`/api/quiz/${quizId}/results`);
      if (response.ok) {
        const data = await response.json();
        setRecommendations(data.recommendations.slice(0, 3));
      } else {
        setError('Não foi possível carregar os resultados.');
      }
    } catch (err) {
      setError('Erro ao carregar os resultados.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Analisando suas respostas...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-lg text-red-600 mb-4">{error}</p>
          <button
            onClick={() => navigate('/')}
            className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Voltar ao início
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="px-6 py-8 bg-white/60 backdrop-blur-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Seus Países Ideais
          </h1>
          <p className="text-lg text-gray-600">
            Com base nas suas respostas, identificamos os países mais compatíveis com o seu perfil
          </p>
        </div>
      </header>

      {/* Results */}
      <main className="px-6 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="grid gap-8 mb-12">
            {recommendations.map((country, index) => (
              <div key={country.id} className="bg-white rounded-3xl shadow-xl overflow-hidden">
                <div className="p-8 md:p-12">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <div className="flex items-center mb-2">
                        <span className="inline-flex items-center justify-center w-8 h-8 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-sm font-bold rounded-full mr-3">
                          {index + 1}
                        </span>
                        <h2 className="text-2xl md:text-3xl font-bold text-gray-900">
                          {country.country_name}
                        </h2>
                      </div>
                      <div className="flex items-center mb-4">
                        <div className="flex-1 bg-gray-200 rounded-full h-3 mr-4">
                          <div
                            className="h-3 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full"
                            style={{ width: `${country.match_score}%` }}
                          ></div>
                        </div>
                        <span className="text-lg font-semibold text-indigo-600">
                          {country.match_score}% compatível
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div className="space-y-4">
                      <div className="flex items-start">
                        <MapPin className="w-5 h-5 text-indigo-600 mt-1 mr-3 flex-shrink-0" />
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-1">Por que é ideal para você</h4>
                          <p className="text-gray-600 text-sm">{country.reasons}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <DollarSign className="w-5 h-5 text-green-600 mt-1 mr-3 flex-shrink-0" />
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-1">Custo de vida</h4>
                          <p className="text-gray-600 text-sm">{country.cost_of_living}</p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-start">
                        <Globe className="w-5 h-5 text-blue-600 mt-1 mr-3 flex-shrink-0" />
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-1">Idioma</h4>
                          <p className="text-gray-600 text-sm">{country.language_info}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <FileText className="w-5 h-5 text-purple-600 mt-1 mr-3 flex-shrink-0" />
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-1">Visto</h4>
                          <p className="text-gray-600 text-sm">{country.visa_info}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-xl p-4">
                    <h4 className="font-semibold text-gray-900 mb-2">Oportunidades profissionais</h4>
                    <p className="text-gray-600 text-sm">{country.opportunities}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* CTA for detailed report */}
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-8 md:p-12 text-center text-white">
            <CreditCard className="w-16 h-16 mx-auto mb-6 opacity-80" />
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              Relatório Completo Personalizado
            </h3>
            <p className="text-lg mb-6 opacity-90 max-w-2xl mx-auto">
              Receba um relatório detalhado com informações específicas sobre visto, processo de imigração, 
              custos detalhados, oportunidades de trabalho e muito mais.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-6">
              <div className="bg-white/20 rounded-lg px-4 py-2 text-sm">
                💳 Pix, Cartão ou PayPal
              </div>
              <div className="bg-white/20 rounded-lg px-4 py-2 text-sm">
                📧 Entrega por email
              </div>
              <div className="bg-white/20 rounded-lg px-4 py-2 text-sm">
                🔒 Pagamento seguro
              </div>
            </div>
            <button
              onClick={() => navigate(`/payment/${quizId}`)}
              className="inline-flex items-center px-8 py-4 bg-white text-indigo-600 text-lg font-semibold rounded-full hover:bg-gray-50 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              Adquirir relatório completo
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
