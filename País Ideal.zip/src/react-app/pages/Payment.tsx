import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { ArrowLeft, CreditCard, Smartphone, DollarSign, Shield, Mail, CheckCircle } from 'lucide-react';

export default function PaymentPage() {
  const { quizId } = useParams();
  const navigate = useNavigate();
  const [selectedMethod, setSelectedMethod] = useState('');
  const [email, setEmail] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);

  const paymentMethods = [
    {
      id: 'pix',
      name: 'Pix',
      description: 'Pagamento instantâneo (Brasil)',
      icon: Smartphone,
      price: 'R$ 47,00'
    },
    {
      id: 'credit_card',
      name: 'Cartão Internacional',
      description: 'Visa, Mastercard, American Express',
      icon: CreditCard,
      price: 'USD $9.90'
    },
    {
      id: 'paypal',
      name: 'PayPal',
      description: 'Aceita múltiplas moedas',
      icon: DollarSign,
      price: 'USD $9.90'
    }
  ];

  const handlePayment = () => {
    // Simulate payment processing
    setShowConfirmation(true);
    
    // In a real implementation, you would:
    // 1. Process the payment with the selected method
    // 2. Save payment record to database
    // 3. Generate and send the detailed report
  };

  if (showConfirmation) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="max-w-md mx-auto px-6">
          <div className="bg-white rounded-3xl shadow-xl p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Pagamento Confirmado!
            </h2>
            
            <p className="text-gray-600 mb-6">
              Obrigado por participar! Seu relatório "Países Ideais para o Seu Perfil" 
              será enviado para o e-mail informado assim que o pagamento for processado.
            </p>
            
            <div className="bg-blue-50 rounded-xl p-4 mb-6">
              <p className="text-sm text-blue-800">
                📧 Em alguns minutos, você receberá um link de acesso seguro ao conteúdo completo.
              </p>
            </div>
            
            <button
              onClick={() => navigate('/')}
              className="w-full px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-200"
            >
              Voltar ao início
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="px-6 py-4 bg-white/60 backdrop-blur-sm border-b border-gray-200">
        <div className="flex items-center max-w-4xl mx-auto">
          <button
            onClick={() => navigate(`/results/${quizId}`)}
            className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar aos resultados
          </button>
        </div>
      </header>

      <main className="px-6 py-12">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                Relatório Personalizado Completo
              </h1>
              <p className="text-lg text-gray-600">
                Receba informações detalhadas sobre seus países ideais
              </p>
            </div>

            {/* What's included */}
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                O que você receberá:
              </h3>
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                  Análise detalhada de cada país
                </div>
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                  Guia completo de vistos
                </div>
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                  Custos de vida detalhados
                </div>
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                  Oportunidades profissionais
                </div>
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                  Dicas de adaptação cultural
                </div>
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                  Recursos úteis e contatos
                </div>
              </div>
            </div>

            {/* Email input */}
            <div className="mb-8">
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Email para recebimento do relatório
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-indigo-600 focus:outline-none transition-colors"
                  placeholder="seu@email.com"
                />
              </div>
            </div>

            {/* Payment methods */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Escolha o método de pagamento:
              </h3>
              <div className="space-y-3">
                {paymentMethods.map((method) => {
                  const IconComponent = method.icon;
                  return (
                    <button
                      key={method.id}
                      onClick={() => setSelectedMethod(method.id)}
                      className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                        selectedMethod === method.id
                          ? 'border-indigo-600 bg-indigo-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <IconComponent className="w-6 h-6 text-indigo-600 mr-3" />
                          <div>
                            <div className="font-semibold text-gray-900">
                              {method.name}
                            </div>
                            <div className="text-sm text-gray-600">
                              {method.description}
                            </div>
                          </div>
                        </div>
                        <div className="text-lg font-bold text-indigo-600">
                          {method.price}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Security notice */}
            <div className="flex items-center text-sm text-gray-600 mb-8 p-4 bg-gray-50 rounded-xl">
              <Shield className="w-5 h-5 mr-2 text-green-600" />
              Pagamento 100% seguro e protegido por criptografia SSL
            </div>

            {/* Payment button */}
            <button
              onClick={handlePayment}
              disabled={!selectedMethod || !email}
              className={`w-full py-4 text-lg font-semibold rounded-xl transition-all ${
                selectedMethod && email
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700 shadow-lg hover:shadow-xl'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              {selectedMethod ? 'Finalizar pagamento' : 'Selecione um método de pagamento'}
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
