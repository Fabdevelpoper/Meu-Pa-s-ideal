import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, ArrowRight, CheckCircle } from 'lucide-react';
import { questions } from '@/react-app/data/questions';
import type { QuizResponse } from '@/shared/types';

export default function QuizPage() {
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [responses, setResponses] = useState<Partial<QuizResponse>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  const handleResponse = (value: string | number) => {
    setResponses(prev => ({
      ...prev,
      [question.id]: value
    }));
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      submitQuiz();
    }
  };

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const submitQuiz = async () => {
    setIsSubmitting(true);
    try {
      const response = await fetch('/api/quiz/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(responses),
      });

      if (response.ok) {
        const result = await response.json();
        navigate(`/results/${result.quiz_response_id}`);
      } else {
        alert('Erro ao enviar respostas. Tente novamente.');
      }
    } catch (error) {
      alert('Erro ao enviar respostas. Verifique sua conexão.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentValue = responses[question.id as keyof QuizResponse];
  const canProceed = currentValue !== undefined && currentValue !== '';

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="px-6 py-4 bg-white/60 backdrop-blur-sm border-b border-gray-200">
        <div className="flex items-center justify-between max-w-4xl mx-auto">
          <button
            onClick={() => navigate('/')}
            className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </button>
          
          <div className="text-sm text-gray-600">
            Pergunta {currentQuestion + 1} de {questions.length}
          </div>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 h-2">
        <div 
          className="h-2 bg-gradient-to-r from-indigo-600 to-purple-600 transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Question */}
      <main className="px-6 py-12">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-8 leading-tight">
              {question.text}
            </h2>

            <div className="space-y-4 mb-8">
              {question.type === 'select' && question.options ? (
                question.options.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleResponse(option.value)}
                    className={`w-full p-4 text-left rounded-xl border-2 transition-all duration-200 hover:border-indigo-300 ${
                      currentValue === option.value
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-900'
                        : 'border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{option.label}</span>
                      {currentValue === option.value && (
                        <CheckCircle className="w-5 h-5 text-indigo-600" />
                      )}
                    </div>
                  </button>
                ))
              ) : question.type === 'number' ? (
                <input
                  type="number"
                  min="16"
                  max="100"
                  value={currentValue || ''}
                  onChange={(e) => handleResponse(parseInt(e.target.value) || '')}
                  className="w-full p-4 text-lg rounded-xl border-2 border-gray-200 focus:border-indigo-600 focus:outline-none transition-colors"
                  placeholder="Digite sua idade"
                />
              ) : (
                <input
                  type={question.id === 'email' ? 'email' : 'text'}
                  value={currentValue || ''}
                  onChange={(e) => handleResponse(e.target.value)}
                  className="w-full p-4 text-lg rounded-xl border-2 border-gray-200 focus:border-indigo-600 focus:outline-none transition-colors"
                  placeholder="Digite sua resposta"
                />
              )}
            </div>

            <div className="flex justify-between">
              <button
                onClick={prevQuestion}
                disabled={currentQuestion === 0}
                className={`px-6 py-3 rounded-xl font-medium transition-all ${
                  currentQuestion === 0
                    ? 'text-gray-400 cursor-not-allowed'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                Anterior
              </button>

              <button
                onClick={nextQuestion}
                disabled={!canProceed || isSubmitting}
                className={`px-8 py-3 rounded-xl font-medium transition-all ${
                  canProceed && !isSubmitting
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700 shadow-lg hover:shadow-xl'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                {isSubmitting ? (
                  'Enviando...'
                ) : currentQuestion === questions.length - 1 ? (
                  'Finalizar'
                ) : (
                  <>
                    Próxima
                    <ArrowRight className="w-4 h-4 ml-2 inline" />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
