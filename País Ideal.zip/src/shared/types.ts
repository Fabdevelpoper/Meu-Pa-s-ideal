import z from "zod";

export const QuizResponseSchema = z.object({
  age: z.number().min(16).max(100),
  current_location: z.string().min(1),
  climate_preference: z.enum(['quente', 'frio', 'temperado']),
  language_preference: z.string().min(1),
  city_size_preference: z.enum(['grandes', 'medias', 'pequenas']),
  lifestyle_preference: z.enum(['tranquilo', 'agitado', 'equilibrado']),
  environment_preference: z.enum(['mar', 'montanhas', 'campos']),
  security_importance: z.enum(['pouco', 'medio', 'muito']),
  cultural_adaptability: z.enum(['sim', 'nao', 'depende']),
  cost_vs_quality_preference: z.enum(['custo_baixo', 'alta_qualidade']),
  professional_area: z.string().min(1),
  culinary_preference: z.enum(['diversificada', 'tradicional']),
  winter_tolerance: z.enum(['sim', 'nao']),
  relocation_purpose: z.enum(['estudo', 'trabalho', 'aposentadoria']),
  social_policies_importance: z.enum(['sim', 'nao']),
  nature_vs_urban: z.enum(['natureza', 'urbano']),
  proximity_to_brazilians: z.enum(['sim', 'nao']),
  social_discipline_preference: z.enum(['sim', 'nao']),
  individual_freedom_importance: z.enum(['pouco', 'medio', 'muito']),
  monthly_budget: z.string().min(1),
  main_motivation: z.string().min(1),
  email: z.string().email()
});

export type QuizResponse = z.infer<typeof QuizResponseSchema>;

export const CountryRecommendationSchema = z.object({
  id: z.number(),
  country_name: z.string(),
  match_score: z.number(),
  ranking: z.number(),
  reasons: z.string(),
  visa_info: z.string(),
  language_info: z.string(),
  cost_of_living: z.string(),
  opportunities: z.string()
});

export type CountryRecommendation = z.infer<typeof CountryRecommendationSchema>;

export const PaymentRecordSchema = z.object({
  id: z.number(),
  quiz_response_id: z.number(),
  payment_method: z.string(),
  payment_status: z.string(),
  amount_cents: z.number(),
  currency: z.string(),
  transaction_id: z.string().nullable(),
  report_sent: z.boolean()
});

export type PaymentRecord = z.infer<typeof PaymentRecordSchema>;

export interface QuizResult {
  quiz_response_id: number;
  recommendations: CountryRecommendation[];
  payment_required: boolean;
}

export interface Question {
  id: string;
  text: string;
  type: 'select' | 'input' | 'number';
  options?: { value: string; label: string }[];
  required: boolean;
}
