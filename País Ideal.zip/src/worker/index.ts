import { Hono } from "hono";
import { cors } from "hono/cors";
import { 
  getOAuthRedirectUrl, 
  exchangeCodeForSessionToken, 
  authMiddleware, 
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME 
} from "@getmocha/users-service/backend";
import { setCookie, getCookie } from "hono/cookie";
import { QuizResponseSchema, type CountryRecommendation } from "@/shared/types";

// Extend the existing Env interface to include our required properties
declare global {
  interface Env {
    MOCHA_USERS_SERVICE_API_URL: string;
    MOCHA_USERS_SERVICE_API_KEY: string;
  }
}

const app = new Hono<{ Bindings: Env }>();

app.use("/*", cors({
  origin: "*",
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowHeaders: ["Content-Type", "Authorization"],
  credentials: true,
}));

// Auth routes
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  try {
    const sessionToken = await exchangeCodeForSessionToken(body.code, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      path: "/",
      sameSite: "none",
      secure: true,
      maxAge: 60 * 24 * 60 * 60, // 60 days
    });

    return c.json({ success: true }, 200);
  } catch (error) {
    return c.json({ error: "Failed to exchange code for token" }, 400);
  }
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Quiz routes
app.post("/api/quiz/submit", async (c) => {
  try {
    const body = await c.req.json();
    const validatedData = QuizResponseSchema.parse(body);
    
    // Get user if authenticated
    const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);
    let userId = null;
    
    if (sessionToken) {
      try {
        const userResponse = await fetch(`${c.env.MOCHA_USERS_SERVICE_API_URL}/users/me`, {
          headers: {
            'x-api-key': c.env.MOCHA_USERS_SERVICE_API_KEY,
            'Authorization': `Bearer ${sessionToken}`
          }
        });
        if (userResponse.ok) {
          const user = await userResponse.json() as { id: string };
          userId = user.id;
        }
      } catch (error) {
        // Continue without user ID if auth fails
      }
    }

    // Save quiz response
    const quizResult = await c.env.DB.prepare(`
      INSERT INTO quiz_responses (
        user_id, email, age, current_location, climate_preference,
        language_preference, city_size_preference, lifestyle_preference,
        environment_preference, security_importance, cultural_adaptability,
        cost_vs_quality_preference, professional_area, culinary_preference,
        winter_tolerance, relocation_purpose, social_policies_importance,
        nature_vs_urban, proximity_to_brazilians, social_discipline_preference,
        individual_freedom_importance, monthly_budget, main_motivation
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      userId,
      validatedData.email,
      validatedData.age,
      validatedData.current_location,
      validatedData.climate_preference,
      validatedData.language_preference,
      validatedData.city_size_preference,
      validatedData.lifestyle_preference,
      validatedData.environment_preference,
      validatedData.security_importance,
      validatedData.cultural_adaptability,
      validatedData.cost_vs_quality_preference,
      validatedData.professional_area,
      validatedData.culinary_preference,
      validatedData.winter_tolerance,
      validatedData.relocation_purpose,
      validatedData.social_policies_importance,
      validatedData.nature_vs_urban,
      validatedData.proximity_to_brazilians,
      validatedData.social_discipline_preference,
      validatedData.individual_freedom_importance,
      validatedData.monthly_budget,
      validatedData.main_motivation
    ).run();

    const quizResponseId = quizResult.meta.last_row_id;

    // Generate recommendations based on quiz responses
    const recommendations = generateCountryRecommendations(validatedData);
    
    // Save recommendations
    for (let i = 0; i < recommendations.length; i++) {
      const rec = recommendations[i];
      await c.env.DB.prepare(`
        INSERT INTO country_recommendations (
          quiz_response_id, country_name, match_score, ranking,
          reasons, visa_info, language_info, cost_of_living, opportunities
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        quizResponseId,
        rec.country_name,
        rec.match_score,
        i + 1,
        rec.reasons,
        rec.visa_info,
        rec.language_info,
        rec.cost_of_living,
        rec.opportunities
      ).run();
    }

    return c.json({
      quiz_response_id: quizResponseId,
      recommendations: recommendations.slice(0, 3),
      payment_required: true
    });

  } catch (error) {
    console.error('Quiz submission error:', error);
    return c.json({ error: "Invalid quiz data" }, 400);
  }
});

app.get("/api/quiz/:id/results", async (c) => {
  const quizId = c.req.param('id');
  
  try {
    const { results } = await c.env.DB.prepare(`
      SELECT cr.* FROM country_recommendations cr
      WHERE cr.quiz_response_id = ?
      ORDER BY cr.ranking ASC
    `).bind(quizId).all();

    if (results.length === 0) {
      return c.json({ error: "Quiz results not found" }, 404);
    }

    return c.json({ recommendations: results });
  } catch (error) {
    return c.json({ error: "Failed to fetch results" }, 500);
  }
});

function generateCountryRecommendations(data: any): CountryRecommendation[] {
  const countries = [
    { name: 'Portugal', baseScore: 85 },
    { name: 'Canadá', baseScore: 80 },
    { name: 'Alemanha', baseScore: 78 },
    { name: 'Austrália', baseScore: 82 },
    { name: 'Nova Zelândia', baseScore: 79 },
    { name: 'Espanha', baseScore: 76 },
    { name: 'França', baseScore: 74 },
    { name: 'Uruguai', baseScore: 72 },
    { name: 'Chile', baseScore: 70 },
    { name: 'Estados Unidos', baseScore: 77 }
  ];

  // Score adjustment logic based on user preferences
  const scoredCountries = countries.map(country => {
    let score = country.baseScore;
    
    // Climate preferences
    if (data.climate_preference === 'temperado') {
      if (['Portugal', 'Espanha', 'França'].includes(country.name)) score += 10;
      if (['Canadá'].includes(country.name)) score -= 5;
    } else if (data.climate_preference === 'frio') {
      if (['Canadá', 'Alemanha'].includes(country.name)) score += 10;
      if (['Espanha', 'Portugal'].includes(country.name)) score -= 5;
    }

    // Language preferences
    if (data.language_preference.toLowerCase().includes('inglês') || data.language_preference.toLowerCase().includes('english')) {
      if (['Canadá', 'Austrália', 'Nova Zelândia', 'Estados Unidos'].includes(country.name)) score += 15;
    }
    if (data.language_preference.toLowerCase().includes('português') || data.language_preference.toLowerCase().includes('portuguese')) {
      if (['Portugal'].includes(country.name)) score += 20;
    }
    if (data.language_preference.toLowerCase().includes('espanhol') || data.language_preference.toLowerCase().includes('spanish')) {
      if (['Espanha', 'Uruguai', 'Chile'].includes(country.name)) score += 15;
    }

    // Security importance
    if (data.security_importance === 'muito') {
      if (['Canadá', 'Nova Zelândia', 'Alemanha'].includes(country.name)) score += 8;
      if (['Estados Unidos'].includes(country.name)) score -= 3;
    }

    // Cost vs quality preference
    if (data.cost_vs_quality_preference === 'custo_baixo') {
      if (['Portugal', 'Espanha', 'Uruguai', 'Chile'].includes(country.name)) score += 8;
      if (['Austrália', 'Nova Zelândia'].includes(country.name)) score -= 5;
    }

    return {
      id: Math.floor(Math.random() * 10000),
      country_name: country.name,
      match_score: Math.max(0, Math.min(100, score)),
      ranking: 0,
      reasons: generateReasons(country.name),
      visa_info: generateVisaInfo(country.name),
      language_info: generateLanguageInfo(country.name),
      cost_of_living: generateCostInfo(country.name),
      opportunities: generateOpportunities(country.name, data.professional_area)
    };
  });

  return scoredCountries
    .sort((a, b) => b.match_score - a.match_score)
    .slice(0, 10);
}

function generateReasons(country: string): string {
  const reasons = [];
  
  if (country === 'Portugal') {
    reasons.push('Idioma português facilita a adaptação');
    reasons.push('Processo de imigração acessível para brasileiros');
    reasons.push('Clima mediterrâneo agradável');
  } else if (country === 'Canadá') {
    reasons.push('Excelente sistema de saúde e educação');
    reasons.push('Políticas de imigração favoráveis');
    reasons.push('Alta qualidade de vida');
  }
  
  return reasons.length > 0 ? reasons.join('. ') : 'País com boas oportunidades para brasileiros.';
}

function generateVisaInfo(country: string): string {
  const visaInfoMap: { [key: string]: string } = {
    'Portugal': 'Visto D7 para aposentados ou visto de trabalho. Processo relativamente simples.',
    'Canadá': 'Express Entry, PNP ou visto de estudante. Processo baseado em pontos.',
    'Alemanha': 'Blue Card para profissionais qualificados ou visto de estudante.',
    'Austrália': 'SkillSelect system, visto de trabalho qualificado ou estudante.',
    'Nova Zelândia': 'Skilled Migrant Category ou visto de trabalho.',
  };
  
  return visaInfoMap[country] || 'Consulte consulado para informações específicas de visto.';
}

function generateLanguageInfo(country: string): string {
  const languageMap: { [key: string]: string } = {
    'Portugal': 'Português - vantagem para brasileiros',
    'Canadá': 'Inglês e francês - inglês é suficiente na maioria das regiões',
    'Alemanha': 'Alemão - necessário aprender para integração completa',
    'Austrália': 'Inglês - essencial para trabalho e vida social',
    'Nova Zelândia': 'Inglês - fundamental para todas as atividades',
  };
  
  return languageMap[country] || 'Consulte idiomas oficiais do país.';
}

function generateCostInfo(country: string): string {
  const costMap: { [key: string]: string } = {
    'Portugal': 'Custo moderado: €1.200-2.000/mês para casal',
    'Canadá': 'Custo alto: CAD $3.500-5.000/mês para casal',
    'Alemanha': 'Custo moderado-alto: €2.500-4.000/mês para casal',
    'Austrália': 'Custo alto: AUD $4.000-6.000/mês para casal',
    'Nova Zelândia': 'Custo alto: NZD $4.000-5.500/mês para casal',
  };
  
  return costMap[country] || 'Custo varia conforme região e estilo de vida.';
}

function generateOpportunities(country: string, profession: string): string {
  return `Oportunidades em ${profession} são ${Math.random() > 0.5 ? 'abundantes' : 'moderadas'} em ${country}. Recomenda-se validar diplomas e certificações localmente.`;
}

export default app;
